import {AppError} from './app.error';

export class InvalidMsalTokenError extends AppError {}
