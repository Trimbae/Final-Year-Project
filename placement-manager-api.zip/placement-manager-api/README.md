## Placement Manager API

This directory contains the source code for the Placement Manager API

## Source Code Directory Structure

 - Controllers - contains controllers containing functions called by endpoints
 - Models - Contains Mongoose Model schemas
 - Routes - contains routes files
 
 ## Running
 
 Start API on localhost port 3000 with 'npm start'