const Task = require('../models/Task');

module.exports = {
    createTask: async (req, res) => {
        try {
            const task = new Task({
                taskId: req.body.taskId,
                name: req.body.name,
                type: req.body.type,
                uploadInfo: req.body.uploadInfo,
                displayName: req.body.displayName,
                description: req.body.description,
                dueDateTime: req.body.dueDateTime,
                orderIndex: req.body.orderIndex,
                isPublished: req.body.isPublished
            });

            const savedTask = await task.save();
            res.send(savedTask);
        }catch(err){
            res.send(err);
        }
    },
    deleteTaskByTaskId: async (req, res) => {
        try {
            const deletedTask = await Task.deleteOne({taskId: req.params.taskId});
            res.send(deletedTask);
        } catch (err) {
            res.send(err);
        }
    },
    getAllTasks: async (req, res) => {
        try {
            const tasks = await Task.find();
            res.send(tasks);
        } catch(err) {
            res.send(err);
        }
    },
    getDraftTasks: async (req, res) => {
        try {
            const tasks = await Task.find({isPublished: false});
            res.send(tasks);
        } catch(err) {
            res.send(err);
        }
    },
    getPublishedTasks: async (req, res) => {
        try {
            const tasks = await Task.find({isPublished: true});
            res.send(tasks);
        } catch(err) {
            res.send(err);
        }
    },
    getTaskByTaskId: async (req, res) => {
        try {
            const files = await Task
                .findOne({
                    taskId: req.params.taskId
                });
            res.send(files);
        } catch(err) {
            res.send(err);
        }
    },
    updateTaskById: async (req, res) => {
        try {
            const task = await Task.findOne({taskId: req.params.taskId});
            task.set(req.body);
            const updatedTask = await task.save();
            res.send(updatedTask);
        } catch (err) {
            res.send(err);
        }
    },
    updateTasksMultiple: async (req, res) => {
        try {
            let updatedTasks = [];
            for (const task of req.body) {
                const updateTask = await Task.findOne({taskId: task.taskId});
                updateTask.set(task);
                const updatedTask = await updateTask.save();
                updatedTasks.push(updatedTask);
            }
            res.send(updatedTasks);
        } catch(err) {
            res.send(err);
        }
    }
};
