const msGraphController = require('../controllers/msGraphDataService');
const User = require('../models/User');

function buildUserObject(dataFromMsGraph, dataFromDB) {
    return {
        name: dataFromDB.name,
        jobTitle: dataFromMsGraph.jobTitle,
        email: dataFromMsGraph.mail,
        universityId: dataFromDB.universityId,
        studentData: {
            supervisorName: dataFromDB.studentData.supervisorName,
            supervisorId: dataFromDB.studentData.supervisorId,
            workplaceSupervisor: dataFromDB.studentData.workplaceSupervisor,
            placementProvider: dataFromDB.studentData.placementProvider,
            startDate: dataFromDB.studentData.startDate
        },
        accessLevel: {
            isAdmin: dataFromDB.accessLevel.isAdmin,
            isSupervisor: dataFromDB.accessLevel.isSupervisor
        },
        tasksCompleted: dataFromDB.tasksCompleted,
        userType: dataFromDB.userType,
        feedback: dataFromDB.feedback
    }
}
/** Simple sort comparator for Strings/Numbers */
function compare(a, b, isAsc) {
    //if one value is null it should be sorted to bottom for asc or top for desc
    if(!a){
        return (isAsc ? 1 : -1);
    }
    if(!b){
        return -1 *(isAsc ? 1 : -1);
    }
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function sortUsers(users, sortBy, sortOrder) {
    return users.sort((a, b) => {
        const isAsc = sortOrder === 'asc';
        switch (sortBy) {
            case 'name': return compare(a.name, b.name, isAsc);
            case 'universityId': return compare(a.universityId, b.universityId, isAsc);
            case 'supervisorName': return compare(a.studentData.supervisorName, b.studentData.supervisorName, isAsc);
            case 'placementProvider': return compare(a.studentData.placementProvider, b.studentData.placementProvider, isAsc);
            default: return 0;
        }
    });
}

module.exports = {
    addFeedbackForUser: async (req, res) => {
        try {
            const feedbackData = req.body;
            const userFromDB = await User.findOne({universityId: req.params.universityId});
            userFromDB.feedback.push(feedbackData);
            const updatedUser = await userFromDB.save();

            res.send(updatedUser);
        } catch (err) {
            res.send(err);
        }
    },
    addTaskToTasksCompleted: async (req, res) => {
        try {
            const userFromDB = await User.findOne({universityId: req.params.universityId});
            userFromDB.tasksCompleted.push(req.body.taskId);
            const updatedUser = await userFromDB.save();
            res.send(updatedUser);
        } catch (err) {
            res.send(err);
        }
    },
    createUser: async (req, res) => {

        const userData = req.body;

        const user = new User({
            universityId: userData.universityId,
            name: userData.name,
            email: userData.email,
            accessLevel: userData.accessLevel,
            studentData: userData.studentData,
            tasksCompleted: [],
            userType: userData.userType
        });

        try {
            const savedUser = await user.save();
            res.send(savedUser);
        }catch(err){
            res.status(500).send({message: err})
        }
    },
    deleteUser: async (req, res) => {
        try {
            const deletedUser = await User.remove({_id: req.params.userId});
            res.send(deletedUser);
        } catch (err) {
            res.send({message: err});
        }
    },
    removeTaskFromTasksCompletedById: async (req, res) => {
        try {
            const userFromDB = await User.findOne({universityId: req.params.universityId});
            const taskId = req.params.taskId;
            userFromDB.tasksCompleted.pull(taskId);
            const updatedUser = await userFromDB.save();
            res.send(updatedUser);
        }catch(err){
            res.send({message: err});
        }
    },
    getCompletedTasks: async (req, res) => {
        try {
            console.log(req.params.universityId);
            const user = await User.findOne({universityId: req.params.universityId});
            res.send(user.tasksCompleted);
        } catch(err) {
            res.send(err);
        }
    },
    getUsers: async (req, res) => {
        try{
            let users;
            const queryParams = req.query;
            const userType = queryParams.userType || '';
            const supervisorId = queryParams.supervisorId;

            if(userType){
                users = await User.find({'userType': userType});
            } else if (supervisorId) {
                users = await User.find({'studentData.supervisorId': supervisorId});
            }
            else {
                users = await User.find();
            }
            res.send(users);
        }catch(err){
            res.send({message: err})
        }
    },
    getUserById: async  (req, res) => {
        try {
            const user = await User.findOne({universityId: req.params.universityId});
            res.send(user);
        } catch(err) {
            res.send(err);
        }
    },
    getUserFromToken: async (req, res) => {
        try{
            // get Microsoft auth token from request header
            const token = req.get('authorization');
            //get data about user from Microsoft Graph
            const dataFromMsGraph = await msGraphController.getUserFromMsGraph(token);

            //if error getting the data from MS Graph with token, return 401 status request not authorized
            if( dataFromMsGraph.error){
                if(dataFromMsGraph.error.code === 'InvalidAuthenticationToken') {
                    res.status(401).send('User not Authorized to access MS Graph data.');
                    return;
                }
            }

            const userEmail = dataFromMsGraph.mail;
            //find user in database from unique university email
            await User.findOne({email: userEmail})
                .then(userData => {
                    //if user found, get call method to get profile photo then build and send user object as response
                    if (userData) {
                        msGraphController.getProfilePhoto(token, userData.universityId).then();
                        res.send(buildUserObject(dataFromMsGraph, userData));
                    //if user not found, send 404 not found error status
                    } else {
                        res.status(404).send('No user data registered to this account.');
                    }
                })
                .catch(err => {
                    res.status(500).send(err);
                });

        }catch (err) {
            res.status(500).send(err);
        }
    },
    updateUserById: async (req, res) => {
        try {
            const id = req.params.universityId, patchData = req.body;
            const userFromDB = await User.findOne({universityId: id});
            userFromDB.set(patchData);
            const updatedUser = await userFromDB.save();

            res.send(updatedUser);
        } catch (err) {
            res.send(err);
        }
    },
    searchUsersAndReturnPage: async (req, res) => {
        try{
            let users;
            const queryParams = req.query;
            //set variables from query parameters
            const filter = queryParams.filter || '',
                pageSize = parseInt(queryParams.pageSize),
                pageIndex = parseInt(queryParams.pageIndex) || 0,
                sortBy = queryParams.sortBy,
                sortOrder = queryParams.sortOrder,
                userType = queryParams.userType;
            //if there is a filter string, query the database for users who's id, name, supervisor name or
            //placement provider match the string
            if (filter) {
                users = await User.aggregate(
                    [
                        {
                            $match: {
                                $and:[
                                    {'userType': userType},
                                    {$or: [
                                            {'universityId': {$regex: '.*' + filter + '.*', $options: 'i'}},
                                            {'name': {$regex: '.*' + filter + '.*', $options: 'i'}},
                                            {'studentData.supervisorName': {$regex: '.*' + filter + '.*', $options: 'i'}},
                                            {'studentData.placementProvider': {$regex: '.*' + filter + '.*', $options: 'i'}}
                                        ]
                                    },
                                ]
                            },
                        },
                    ]);
            //if no filter, fetch list of all users matching userType
            } else {
                users = await User.find({'userType': userType});
            }
            //sort users using by sortBy field in ascending or descending order
            sortUsers(users, sortBy, sortOrder);
            //slice the data to the correct page size and position
            const initialPos = pageIndex * pageSize;
            const usersPage = users.slice(initialPos, initialPos + pageSize);
            //send data response
            res.send(usersPage);
        } catch(err) {
            res.status(500).send(err);
        }
    },
    countUsers: async (req, res) => {
        try {
            let count;
            const queryParams = req.query;
            const userType = queryParams.userType;

            if (userType) {
                count = await User.countDocuments({'userType': userType});
            } else {
                count = await User.countDocuments();
            }
            res.send({userCount: count});
        } catch(err){
            res.send(err);
        }
    }
};
