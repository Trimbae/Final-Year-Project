const File = require('../models/File');

module.exports = {
    deleteFileById: async (req, res) => {
        try {
            const deletedFile = await File.deleteOne({_id: req.params.fileId});
            res.send(deletedFile);
        } catch (err) {
            res.send(err);
        }
    },
    getFileByTaskForUser: async (req, res) => {
        try {
            const files = await File
                .find({
                    taskId: req.params.taskId,
                    universityId: req.params.universityId
                });
            res.send(files);
        } catch(err) {
            res.send(err);
        }
    },
    saveFile: async (req, res) => {

        try {
            const file = new File({
                filename: req.body.files.filename,
                fileId: req.body.files.fileId,
                fileType: req.body.files.fileType,
                taskId: req.body.files.taskId,
                universityId: req.body.files.universityId,
                data: req.body.files.data,
                comments: req.body.comments,
                date: new Date()
            });

            const savedFile = await file.save();
            res.send(savedFile);
        }catch(err){
            res.status(500).send({message: err})
        }
    }
};
