const https = require('https');
const Stream = require('stream').Transform;
const fs = require('fs');
const path = require('path');

//getUserFromMsGraph('eyJ0eXAiOiJKV1QiLCJub25jZSI6ImcySFVTTHJhV3g3cGl2dHRGZ3Bxa19hMFVESjcyRVRNeUxJWllkWG5McVUiLCJhbGciOiJSUzI1NiIsIng1dCI6IllNRUxIVDBndmIwbXhvU0RvWWZvbWpxZmpZVSIsImtpZCI6IllNRUxIVDBndmIwbXhvU0RvWWZvbWpxZmpZVSJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9iZGI3NGIzMC05NTY4LTQ4NTYtYmRiZi0wNjc1OTc3OGZjYmMvIiwiaWF0IjoxNTg1NzU4ODk0LCJuYmYiOjE1ODU3NTg4OTQsImV4cCI6MTU4NTc2Mjc5NCwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IjQyZGdZTkJhZGU3YW1pKzFiamxoUjNVMFJmeWFVazJ2WHp2cXQ4M1A3YWdXMXg4alRUTUEiLCJhbXIiOlsicHdkIl0sImFwcF9kaXNwbGF5bmFtZSI6IkdyYXBoIGV4cGxvcmVyIiwiYXBwaWQiOiJkZThiYzhiNS1kOWY5LTQ4YjEtYThhZC1iNzQ4ZGE3MjUwNjQiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IlRyaW1ieSIsImdpdmVuX25hbWUiOiJNYXR0aGV3IiwiaXBhZGRyIjoiODIuOS4yMzkuMTc3IiwibmFtZSI6Ik1hdHRoZXcgVHJpbWJ5Iiwib2lkIjoiNzM0N2ZjNzktNmMwMC00MDZkLTkxYjQtOTVjMDIzNDJlMmI3Iiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTIxMTExODcyMy0zNTAwMTYxNS0xMDM4MjIxNjcwLTE2NTUxNyIsInBsYXRmIjoiNSIsInB1aWQiOiIxMDAzQkZGRDk5NjQwMDIxIiwic2NwIjoiQ2FsZW5kYXJzLlJlYWRXcml0ZSBDb250YWN0cy5SZWFkV3JpdGUgRGV2aWNlTWFuYWdlbWVudEFwcHMuUmVhZC5BbGwgRGV2aWNlTWFuYWdlbWVudEFwcHMuUmVhZFdyaXRlLkFsbCBEZXZpY2VNYW5hZ2VtZW50Q29uZmlndXJhdGlvbi5SZWFkLkFsbCBEZXZpY2VNYW5hZ2VtZW50Q29uZmlndXJhdGlvbi5SZWFkV3JpdGUuQWxsIERldmljZU1hbmFnZW1lbnRNYW5hZ2VkRGV2aWNlcy5Qcml2aWxlZ2VkT3BlcmF0aW9ucy5BbGwgRGV2aWNlTWFuYWdlbWVudE1hbmFnZWREZXZpY2VzLlJlYWQuQWxsIERldmljZU1hbmFnZW1lbnRNYW5hZ2VkRGV2aWNlcy5SZWFkV3JpdGUuQWxsIERldmljZU1hbmFnZW1lbnRSQkFDLlJlYWQuQWxsIERldmljZU1hbmFnZW1lbnRSQkFDLlJlYWRXcml0ZS5BbGwgRGV2aWNlTWFuYWdlbWVudFNlcnZpY2VDb25maWcuUmVhZC5BbGwgRGV2aWNlTWFuYWdlbWVudFNlcnZpY2VDb25maWcuUmVhZFdyaXRlLkFsbCBEaXJlY3RvcnkuQWNjZXNzQXNVc2VyLkFsbCBEaXJlY3RvcnkuUmVhZC5BbGwgRGlyZWN0b3J5LlJlYWRXcml0ZS5BbGwgRmlsZXMuUmVhZFdyaXRlLkFsbCBHcm91cC5SZWFkV3JpdGUuQWxsIElkZW50aXR5Umlza0V2ZW50LlJlYWQuQWxsIE1haWwuUmVhZFdyaXRlIE1haWxib3hTZXR0aW5ncy5SZWFkV3JpdGUgTm90ZXMuUmVhZFdyaXRlLkFsbCBvcGVuaWQgUGVvcGxlLlJlYWQgcHJvZmlsZSBSZXBvcnRzLlJlYWQuQWxsIFNpdGVzLlJlYWRXcml0ZS5BbGwgVGFza3MuUmVhZFdyaXRlIFVzZXIuUmVhZCBVc2VyLlJlYWRCYXNpYy5BbGwgVXNlci5SZWFkV3JpdGUgVXNlci5SZWFkV3JpdGUuQWxsIGVtYWlsIiwic2lnbmluX3N0YXRlIjpbImttc2kiXSwic3ViIjoiQVpPcGVxTl9zS1gybXpxS0hBbDcyODJGWFVQSzhENk5PNmlVNzZ2SlFzTSIsInRpZCI6ImJkYjc0YjMwLTk1NjgtNDg1Ni1iZGJmLTA2NzU5Nzc4ZmNiYyIsInVuaXF1ZV9uYW1lIjoiVHJpbWJ5TUBjYXJkaWZmLmFjLnVrIiwidXBuIjoiVHJpbWJ5TUBjYXJkaWZmLmFjLnVrIiwidXRpIjoiN1pmbHJQWmdCRU9RLTF2V0hQd3RBQSIsInZlciI6IjEuMCIsInhtc19zdCI6eyJzdWIiOiJDcm9mWUtjYWNISjNVSE9sMFd5ZGZfemN0M25FREY5d215TF8yRXg4RXdBIn0sInhtc190Y2R0IjoxMzY2MTg4NDcyfQ.Q5kFblRVwfwwxXDwX1Z4gOo9_BM7Y_TxnlsQHHTAqdHluq9y6CUq9fV1SzPZfJU1nCZTk1wbCpT5sPpMdmJccTn5REYnKa5K5KlRtYqKW1p-JVj4LeV0x04FKjQ_anN4JtT5ZObaVtdzVfWptSTqqAkZkwhH5CIlZYPrYsisyvArimfIHvEsGmoe38L6BjLLQwZG9XrQTlnw-J74okrDBq80IXugO27na78Hgi0NyXJAbKx02SuNl8I4pcMQxnAxZOfStOhMk-y5MdzN4kihhqICQ3MxavXvnz2HdndixwQzHQaVR9k8Rc5WlgxybZvRKP_1QgvHmV1JmoZhK4mbGg');


module.exports = {
    getUserFromMsGraph: (authToken) => {

        const options = {
            headers: {
                Authorization: authToken
            }
        };

        let data = "";

        return new Promise(function (resolve, reject) {
            https
                .get('https://graph.microsoft.com/v1.0/me', options, res => {

                    //data received
                    res.on('data', dataChunk => {
                        data += dataChunk;
                    });

                    //when whole response received
                    res.on('end', () => {
                        let user = JSON.parse(data);
                        console.log('successfully retrieved user data from MS Graph');
                        resolve(user);
                    });

                    //error handling
                    res.on('error', err => {
                        console.log('Error: ' + err.message);
                        reject(err);
                    })
                });
        })
    },
    getProfilePhoto: async (authToken, universityID) => {
        //set path for image file
        let filename = path.resolve(__dirname + '/../public/images/' + universityID + '.jpg');

        //if picture already saved locally, we dont need to do anything
        if (fs.existsSync(filename)) {
            console.log('File already saved');
            return null;
        }

        const options = {
            headers: {
                Authorization: authToken
            }
        };

        let img = new Stream();

        return new Promise(function (resolve, reject) {
            https
                .get('https://graph.microsoft.com/v1.0/me/photo/$value', options, res => {

                    if(res.headers["content-type"] !== 'image/jpeg') {
                        reject('user has no profile image');
                    }

                    //data received
                    res.on('data', dataChunk => {
                        img.push(dataChunk);
                    });

                    //when whole response received
                    res.on('end', () => {
                        console.log(res.headers);
                        fs.writeFile(filename, img.read(), 'binary', err => {
                            if(err) throw err;
                            console.log('File Saved');
                        });
                        resolve();
                    });

                    //error handling
                    res.on('error', err => {
                        console.log('Error: ' + err.message);
                        reject(err);
                    })
                });
        })
    }
};

