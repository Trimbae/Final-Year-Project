const Meeting = require('../models/Meeting');

module.exports = {
    deleteMeeting: async (req, res) => {
        try {
            const deletedMeeting = await Meeting.deleteOne({_id: req.params.meetingId});
            res.send(deletedMeeting);
        } catch (err) {
            res.send(err);
        }
    },
    getMeetingsById: async (req, res) => {
        let meetings;
        const queryParams = req.query;

        const studentId = queryParams.studentId || '',
        supervisorId = queryParams.supervisorId || '';

        try {
            meetings = await Meeting.find({studentId: studentId, supervisorId: supervisorId});
            res.send(meetings);
        } catch(err) {
            res.send(err);
        }
    },
    postMeeting: async (req, res) => {
        const meetingData = req.body;

        const meeting = new Meeting({
            name: meetingData.name,
            taskId: meetingData.taskId,
            studentId: meetingData.studentId,
            supervisorId: meetingData.supervisorId,
            time: meetingData.time,
            location: meetingData.location,
            approved: false

        });

        try {
            const savedMeeting = await meeting.save();
            res.send(savedMeeting);
        }catch(err){
            res.status(500).send({message: err})
        }
    },
    updateMeeting: async (req, res) => {
        try {
            const id = req.params.meetingId, patchData = req.body;
            const updatedMeeting = await Meeting.findByIdAndUpdate(id, patchData);

            res.send(updatedMeeting);
        } catch (err) {
            res.send(err);
        }
    }
};
