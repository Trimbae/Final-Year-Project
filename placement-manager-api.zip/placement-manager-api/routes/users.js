const express = require('express');
const router = express.Router();
const usersController = require('../controllers/usersController');


/* GET users listing. */
router.get('/', usersController.getUsers);

//GET retrieves current user information based on MSAL auth token
router.get('/me', usersController.getUserFromToken);

//GET search for specific set of users based on queryParams
router.get('/search', usersController.searchUsersAndReturnPage);

//GET count number users by userType
router.get('/count', usersController.countUsers);

//GET get user by Univeristy Id
router.get('/:universityId', usersController.getUserById);

//GET get tasks completed for user
router.get('/:universityId/tasks', usersController.getCompletedTasks);

//DELETE specific user
router.delete('/:userId', usersController.deleteUser);

router.delete('/:universityId/task/:taskId', usersController.removeTaskFromTasksCompletedById);

//PATCH update user by Id
router.patch('/:universityId/', usersController.updateUserById);

//PATCH add feedback for user
router.patch('/:universityId/feedback', usersController.addFeedbackForUser);

//PATCH add task to tasks completed
router.patch('/:universityId/tasks', usersController.addTaskToTasksCompleted);

//POST new user
router.post('/', usersController.createUser);

module.exports = router;
