const express = require('express');
const router = express.Router();
const tasksController = require('../controllers/tasksController');

//GET get all tasks
router.get('/', tasksController.getAllTasks);

//GET get draft tasks
router.get('/drafts', tasksController.getDraftTasks);

//GET get published tasks
router.get('/published', tasksController.getPublishedTasks);

//GET get task by taskId
router.get('/:taskId', tasksController.getTaskByTaskId);

//POST create new task
router.post('/', tasksController.createTask);

//PATCH update multiple tasks
router.patch('/', tasksController.updateTasksMultiple);

router.put('/:taskId', tasksController.updateTaskById);

router.delete('/:taskId', tasksController.deleteTaskByTaskId);

module.exports = router;
