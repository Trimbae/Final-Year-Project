const express = require('express');
const router = express.Router();


const meetingsController = require('../controllers/meetingsController');

//DELETE by meeting Id
router.delete('/:meetingId', meetingsController.deleteMeeting);


/* GET meetings by student and supervisor id. */
router.get('/', meetingsController.getMeetingsById);

//PATCH update meeting by Id
router.patch('/:meetingId', meetingsController.updateMeeting);

//POST new meeting
router.post('/', meetingsController.postMeeting);

module.exports = router;
