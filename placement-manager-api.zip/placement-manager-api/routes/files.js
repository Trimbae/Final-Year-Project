const express = require('express');
const router = express.Router();
const filesController = require('../controllers/filesController');


router.delete('/:fileId', filesController.deleteFileById);

router.get('/:taskId/:universityId', filesController.getFileByTaskForUser);

router.post('/', filesController.saveFile);

module.exports = router;
