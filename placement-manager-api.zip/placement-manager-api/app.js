const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');

// package to control cross-origin resource sharing, only requests from permitted URL will be accepted
const cors = require('cors');
const corsWhitelist = ['http://localhost:4200', 'https://matt-trimby.com'];
const corsOptions = {
  origin: function(origin, callback) {
    if (corsWhitelist.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  }
};
// set up routing
const meetingsRouter = require('./routes/meetings');
const filesRouter = require('./routes/files');
const usersRouter = require('./routes/users');
const tasksRouter = require('./routes/tasks');


const app = express();
const mongoose = require('mongoose');
require('dotenv/config');

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json({limit:'50mb'}));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors(corsOptions));
//app.use(cors());

app.use('/meetings', meetingsRouter);
app.use('/files', filesRouter);
app.use('/users', usersRouter);
app.use('/tasks', tasksRouter);




// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

//connect to DB
mongoose.connect(process.env.DB_CONNECTION, {useNewUrlParser: true, useUnifiedTopology: true}, () => {
  console.log('connected to DB')
});


module.exports = app;
