const mongoose = require('mongoose');

const MeetingSchema = mongoose.Schema(
    {
        name: {
            type: String,
            required: true
        },
        taskId: {
            type: String,
            required: true
        },
        studentId: {
            type: String,
            required: true
        },
        supervisorId: {
            type: String,
            required: true
        },
        location: {
            type: String
        },
        time: {
            type: Date,
            required: true
        },
        approved: {
            type: Boolean,
            required: true
        }
    }
);

module.exports = mongoose.model('Meeting', MeetingSchema);
