const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({
    universityId: {
        type: String,
        required: true,
        unique: true
    },
    name: {
        type: String,
        required: true
    },
    email: {
        type: String
    },
    userType: {
        type: String,
        required: true
    },
    tasksCompleted: [String],
    studentData: {
        supervisorName: String,
        supervisorId: String,
        workplaceSupervisor: String,
        placementProvider: String,
        startDate: Date
    },
    accessLevel: {
        isAdmin: {
            type: Boolean,
            required: true
        }
    },
    feedback: {
        type: Array
    }
});

module.exports = mongoose.model('Users', UserSchema);
