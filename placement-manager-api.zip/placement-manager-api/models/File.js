const mongoose = require('mongoose');

const FileSchema = mongoose.Schema(
    {
        filename: {
            type: String,
            required: true,
        },
        fileId: {
            type: String,
            required: true,
        },
        taskId: {
            type: String,
            required: true
        },
        universityId: {
            type: String,
            required: true
        },
        data: {
            type: String,
            required: true,
        },
        fileType: {
            type: String,
            required: true
        },
        comments: {
            type: String
        },
        date: {
            type: Date,
            required: true
        }
    }
);

module.exports = mongoose.model('File', FileSchema);
