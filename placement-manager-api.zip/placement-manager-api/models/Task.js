const mongoose = require('mongoose');

const TaskSchema = mongoose.Schema(
    {
        taskId: {
            type: String,
            required: true,
            unique: true
        },
        name: {
            type: String,
            required: true,
        },
        type: {
            type: String,
            required: true
        },
        uploadInfo: {
            uploadType: String,
            marksAvailable: Number
        },
        displayName: {
            type: String,
            required: true
        },
        description: {
            type: String,
            required: true
        },
        dueDateTime: {
            type: Date,
            required: true
        },
        orderIndex: {
            type: Number
        },
        isPublished: {
            type: Boolean,
            required: true
        }

    }
);

module.exports = mongoose.model('Task', TaskSchema);
